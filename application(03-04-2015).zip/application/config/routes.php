<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "welcome";
$route['404_override'] = '';

$route['signup-successful'] = 'signup/success';
$route['admin'] = "admin/dashboard";
$route['admin/logout'] = "admin/admin/logout";
$route['forgot-password'] = 'login/forgot_password';
$route['login/get-password/(:any)'] = 'login/get_password/$1';
$route['logout'] = 'login/logout';
//$route['ad/caregiver'] = 'ad/index/$1';
//$route['ad/careseeker'] = 'ad/index/$1';
$route['ad/caregiver/(:any)'] = 'ad/index/$1/$2';
$route['ad/careseeker/(:any)'] = 'ad/index/$1/$2';
$route['about-us'] = 'cms/aboutus';
//$route['help'] = 'cms/help';
$route['terms-and-conditions'] = 'cms/termsandconditions';
$route['staying-safe'] = 'cms/stayingsafe';
$route['tips-and-tools'] = 'cms/tipsandtools';
$route['user/upgrademembership'] = 'payment/upgrademembership';
$route['sserddaliameyfirev/(:any)'] = 'user/verifyemailaddress';
$route['admin/user/logs/views/(:any)'] = 'admin/user/viewlog/$1';
$route['admin/user/profile/view/(:any)'] = 'admin/user/viewprofile/$1';
$route['admin/user/logs/delete/(:any)'] = 'admin/user/deletelog/$1';
$route['caregivers/organization']	     = 'caregivers';
$route['careseekers/organization']	     = 'careseekers';


/* End of file routes.php */
/* Location: ./application/config/routes.php */