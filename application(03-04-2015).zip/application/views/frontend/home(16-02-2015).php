<?php home_flash();?>
<main class="site-main">
    <section class="banner">
        <ul id="site-banner" class="banner-main">
            <li class="banner-item" style='background-image:url(img/banner-bg.jpg);'>
                <div class="container">
                    <div class="banner-text">
                        <h2 class="banner-title">
                            Connecting <br />Jewish Families <br />with CareGivers
                        </h2>

                        <div class='banner-sub-title'>
                                <?php /* <a href="<?php echo site_url('signup?ac=2')?>">I am a Parent</a>
                                <br />

                                <a href="<?php echo site_url('signup?ac=1')?>">I am a Caregiver</a>
                                <br />

                                <a href="<?php echo site_url('signup?ac=3')?>">I am a Care Orgainzation</a>
                                <br /> */?>
                                <p>I am a</p>
                                <div class="amlabel"><label> Parent<input type="radio" name="parent" class="select" value="2">  </label>
                                <br />

                                <label> Caregiver <input type="radio" name="parent" class="select" value="1"> </label>
                                <br />

                                <label>Care Organization <input type="radio" name="parent" class="select" value="3"> </label>
                                </div>
                                <br />

                                <a href="javascript:void(0);" class="link-block browse-caregivers">Join for free</a>
                        </div>
                        <?php /* <a href="<?php echo site_url("ad");?>" class="link-block browse-caregivers">PLACE AN AD FOR FREE</a> */ ?>
                    </div>
                    <div class="banner-images">
                        <ul>
                            <li><a title="Child Care"><img src="img/banner%20images/woman-taking-care-of-girl.png" alt="#"/><span>Child Care</span></a></li>
                            <li><a title="Senior Care"><img src="img/banner%20images/man-helping-elderly.png" alt="#"/><span>Senior Care</span></a></li>
                            <li><a title="Special Needs Care"><img src="img/banner%20images/woman-and-child.png" alt="#"/><span>Special Needs Care</span></a></li>
                            <li><a title="Cleaning & Household Help"><img src="img/banner%20images/woman-doing-house-chores.png" alt="#"/><span>Cleaning & Household Help</span></a></li>                            
                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </section>

    <section class="callout">
        <div class="container">
            <div class="row">
                <div class="col-half">
                    <div class='callout-block'>
                        <h2 class="title">
                            <span class="looking-for-care">Looking for care?</span><br/>
                            Find quality <em>Caregivers</em> in <em>your area</em>
                        </h2>
                        <a href="<?php echo site_url('caregivers');?>" class="place-ad-link link-block">FIND A CAREGIVER</a>
                    </div>
                </div>
                <div class="col-half">
                    <div class='callout-block'>
                        <h2 class="title">
                            <span class="looking-for-care-job">Looking for a care job?</span><br/>
                            Find <em>Jobs</em> in <em>your area</em>
                        </h2>
                        <a href="<?php echo base_url('careseekers') ?>" class="place-ad-link link-block">FIND A JOB</a>
                    </div>
                </div>
                <div class="clearfix"></div>
                <!--<div class="col-full">
                    <p class="callout-text">If you represent a care giving institution, <a href="<?php echo site_url();?>ad">click here</a>
                    </div>-->
                </div>
            </div>
        </section>

        <section class="how-it-works">
            <div class="container">
                <h2 class="title">How it works <span><a href="<?php echo site_url();?>howitworks">Learn More</a></span></h2>
                
                <ol class="how-it-works-display">
                    <li class="item lookingfor">
                        <h3 class="sub-title">I am looking for</h3>
                        <a href="<?php echo site_url();?>caregivers">
                            <i class="icon-caregiver"></i><br/>
                            Caregiver
                        </a>
                        <a href="<?php echo site_url();?>careseekers">
                            <i class="icon-find-job"></i><br/>
                            Find a Job
                        </a>
                        <a href="<?php echo site_url();?>therapist">
                            <i class="icon-employees"></i><br/>
                            Employees
                        </a>
                    </li>
                    <li class="item create-listing">
                        <h3 class="sub-title">Create a Listing</h3>
                        <a href="<?php echo site_url();?>signup">
                            <i class="icon-profile"></i><br/>
                            Create a Profile
                        </a>
                        <a href="<?php echo site_url();?>ad">
                            <i class="icon-job"></i><br/>
                            Post a Job
                        </a>

                        <!-- <ol class="createlisting">
                            <li><a href="<?php //echo site_url();?>signup">Create a Profile</a></li>
                            <li><a href="<?php //echo site_url();?>ad">Post a Job</a></li>
                        </ol> -->
                    </li>
                    <li class="item item-search">
                        <h3 class="sub-title">Search</h3>
                        <a href="#"><i class="icon-search-circle"></i></a>

                        <p>
                            Ut at metus auctor, fermentum justo ut, egestas neque. Nunc in ultrices leo, et pharetra dolor.
                            Donec
                        </p>
                    </li>
                    <li class="item item-hire">
                        <h3 class="sub-title">Hire</h3>
                        <a href="#"><i class="icon-hire"></i></a>

                        <p>Ut at metus auctor, fermentum justo ut, egestas neque. Nunc in ultrices leo, et pharetra dolor.
                            Donec</p>
                        </li>
                    </ol>
                </div>
            </section>
            <!--end .how-it-works-->

            <section class="safety-first">
                <div class="container">

                        <h2 class="title">We put safety first</h2>
                    <div class="row">
                        <div class="col-half border-right">            

                            <h2>We put safety first</h2>
                                <?php 
                            $safetyposts = Blog_model::getSafetyFirstPosts(22);
                            if(is_array($safetyposts)){
                                foreach($safetyposts as $key => $safety):
                            
                        ?>

                            <div class="col-half">
                                <article>
                                    <?php 
                                        if($key == 0){
                                            echo '<i class="icon-crowd"></i>';
                                        }
                                        if($key == 1){
                                            echo '<i class="icon-coins"></i>';
                                        }
                                    ?>

                                    <h3 class="sub-title">
                                        <a href="<?php echo $safety['guid'];?>" style="color:#fff;"><?php echo $safety['post_title'];?></a>
                                     </h3>

                                    <div class="content">
                                        <p>
                                           <?php echo substr($safety['post_content'],0,200);?>
                                        </p>
                                    </div>
                                </article>
                            </div>
                            <?php 
                                endforeach;
                                }
                            ?>
                         
                        </div>
                        <?php 
                            $adviceandtools = Blog_model::getAdvicePosts(21);
                             
                        ?>
                        <div class="col-half padleft">
                            <h2>Tips and tools</h2>
                            <?php 
                                if(is_array($adviceandtools)){
                                        foreach($adviceandtools as $key => $advice):
                            ?>
                            <div class="col-half">
                                <article>
                                 <?php 
                                            if($key == 0){
                                                echo  '<i class="icon-comment"></i>';
                                            }else{
                                                echo '<i class="icon-doc"></i>';
                                            }
                                        ?>
                                    <h3 class="sub-title">
                                        <a href="<?php echo $safety['guid'];?>" style="color:#fff;"><?php echo $advice['post_title'];?></a>
                                    </h3>

                                    <div class="content">
                                        <p>
                                            <?php echo substr($advice['post_content'],0,200);?>
                                        </p>
                                    </div>
                                </article>
                            </div>
                            <?php 
                                endforeach;
                              }
                            ?>
                        </div>
                    </div>
                </div>
                <!--end .container-->
            </section>

            <!--end .safety-first-->

            <section class="client-say">
                <div class="container">
                    <h2 class="title">What Our Clients are Saying</h2>
                    <article>
                        <p class="testimonial">
                            “<?php
                            $desc = nl2br(strip_tags($testimonial[0]->testimonial_description));
                            echo strip_tags($desc); 
                            ?>”
                            <br />
                            <span class="author"><?php echo $testimonial[0]->testimonial_by;?></span>
                        </p>
                    </article>
                    <article>
                        <p class="testimonial">
                            “<?php

                            $desc = nl2br(strip_tags($testimonial[1]->testimonial_description));
                            echo strip_tags($desc); 
                            ?>”
                            <br />
                            <span class="author"><?php echo $testimonial[1]->testimonial_by;?></span>
                        </p>
                    </article>
                </div>
            </section>
        </main>

        <link rel="stylesheet" href="http://code.jquery.com/ui/1.11.2/themes/smoothness/jquery-ui.css"/><!--for datepicker-->
        <script src="http://code.jquery.com/ui/1.11.2/jquery-ui.js"></script><!--for datepicker-->

        <script type="text/javascript">
            $(document).ready(function(){
                 // dialog box
                var $myDialog = $('<div></div>')
                    .html('Please select care type')
                    .dialog({
                    autoOpen: false,
                    title: 'Select Care Type',
                    resizable: false,

                    buttons: {
                      "Ok": function () {
                        $(this).dialog("close");
                      },
                    }
                });

                $('.browse-caregivers').click(function(e){
                    e.preventDefault();
                        var selected_category = $("input[type='radio'].select:checked").val();
                        if(selected_category == undefined){
                            //alert('Please select the care type');return false;
                            return $myDialog.dialog('open'); 
                        }else{
                            window.location= '<?php echo site_url();?>signup?ac='+selected_category;    
                        }
                }); 
            });
        </script>