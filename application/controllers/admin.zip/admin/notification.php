<?php 
	if(!defined('BASEPATH'))exit('No direct script access allowed');
	class Notification extends CI_Controller{
		public function __construct(){
			parent::__construct();

			if (!$this->session->userdata('admin_username')) {
	            redirect('admin/login');
	        }
	        $this->load->model('admin/notification_model');
		}

		public function index(){

			$data = array(
				'main_content'  => 'admin/notification/index',
				'data'   		=> $this->notification_model->getAllNotification()
			);
			$this->load->view(BACKEND_TEMPLATE,$data);
		}

		public function add(){
			if(isset($_POST['save_admin_info'])){
				$this->notification_model->add();
				redirect('admin/notification','refresh');
				$this->session->flashdata('success', 'Notification added successfully.');
			}
			$data = array(
				'main_content' => 'admin/notification/add'
			);

			$this->load->view(BACKEND_TEMPLATE, $data);
		}

		public function edit($id = null){
			if(isset($_POST['save_admin_info'])){
				$this->notification_model->edit($id);
				redirect('admin/notification','refresh');
				$this->session->flashdata('success', 'Notification updated successfully');
			}
			$data = array(
				'main_content'	=> 'admin/notification/edit',
				'editData'		=> $this->notification_model->getById($id)
			);
			$this->load->view(BACKEND_TEMPLATE,$data);
		}

		public function delete($id = null){
			$this->notification_model->delete($id);
			$this->session->flashdata('success','Notification deleted successfully');
			redirect('admin/notification','refresh');
		}

		public function send($id= null){
			if(isset($_POST['notification_recepients']))
				$notification_recepients = $_POST['notification_recepients'];
			if(isset($_POST['group']))
				foreach($_POST['group'] as $group):
					
				endforeach;

			$data = array(
				'main_content'	=> 'admin/notification/send',
				'editData'		=> $this->notification_model->getById($id)
			);

			$this->load->view(BACKEND_TEMPLATE,$data);
		}

	}
?>