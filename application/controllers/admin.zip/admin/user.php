<?php  if (!defined('BASEPATH')) exit('No direct script access allowed');

class User extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('admin_username')) {
            redirect('admin/login');
        }
        $this->load->model('common_model');
        $this->load->model('admin/user_model');
    }

    function index(){
        $data['title'] = 'User Manager';
        $data['user_data'] = $this->common_model->get_all('tbl_user');
  
        $data['main_content'] = 'admin/user/user';
        $this->load->view(BACKEND_TEMPLATE, $data);
    }

    function logs(){       
        $data['title'] = 'User Log Manager';
        $data['user_data'] = $this->common_model->getAllUserLogs();
        $data['main_content'] = 'admin/user/user_logs';
        $this->load->view(BACKEND_TEMPLATE, $data);
    }

    function edit($id = '')
    {
        if($_POST) {
            $data = $_POST;
           // $dob = $data['month'].'/'.$data['day'].'/'.$data['year'];
            $edit = array(
                'email' => $data['email'],
                //'dob' => strtotime($dob),
              //  'age' => get_age($dob),
                'gender' => (isset($data['gender']))?$data['gender']:'',
                'account_type' => $data['account_type'],
                'first_name' => $data['fname'],
               // 'middle_name' => $data['mname'],
                //'last_name' => $data['lname'],
                'care_type' => $data['care_type'],
                'status' => (isset($data['activate'])) ? 1 : 0,
                'original_password' => $data['password'],
                'account_category' => $data['account_category']
            );
            if(isset($data['password']) && $data['password'] != '') {
                $edit['password'] = sha1($data['password']);
            }
            $q = $this->common_model->update('tbl_user', $edit, array('id' => $id));
            if($q) {
                $this->session->set_flashdata('msg', 'User data saved');
            } else {
                $this->session->set_flashdata('msg', 'User data not saved');
            }
            redirect('admin/user');
        } else {
            $data['main_content'] = 'admin/user/user_edit';
            $data['detail'] = $this->common_model->get_where('tbl_user', array('id' => $id));
            $data['care'] = $this->common_model->get_where('tbl_care', array('service_type' => $data['detail'][0]['account_category']), 'service_by ASC');
            $this->load->view(BACKEND_TEMPLATE, $data);
        }
    }


    public function delete($id){
        $id = $this->uri->segment(4);
        $del = $this->db->delete('tbl_user',array('id'=>$id));
        if($del){
            $this->session->set_flashdata('success', 'User deleted successfully');
            redirect('admin/user/index','refresh');
        }

    }

    public function profilepicture(){
        
        $data = array(
                'recordData'   => $this->common_model->getAllProfileImages(),
                'main_content' => 'admin/user/profilepicture', 
        );

        $this->load->view(BACKEND_TEMPLATE,$data);
    }

   /* public function deleteProfileImage($id = ''){
        $id = $this->uri->segment(4);
        var_dump($id);exit();
    } */

    public function changeStatus(){
        $user_id = $this->uri->segment(4);
        $task = $this->uri->segment(5);

        $this->user_model->updateImageStatus($user_id,$task);
        $this->session->set_flashdata('success', 'Profile picture status changed successfully');
        redirect('admin/user/profilepicture','refresh');
    }

    public function view($id=''){
        $data['detail']         = $this->common_model->get_where('tbl_user', array('id' => $id));
        $data['payment_detail'] = $this->common_model->get_where('tbl_payments', array('user_id' => $id));
        $data['care_types']      = $this->common_model->getCareType();
        $data['main_content']   = 'admin/user/view';

        $this->load->view(BACKEND_TEMPLATE,$data);
    }

    public function viewlog($id = ''){

        $data = array(
            'main_content' => 'admin/user/viewlogs',
            'recordData'   => $this->user_model->getLogDataById($id)
        );

        $this->load->view(BACKEND_TEMPLATE,$data);
    }

    public function profile(){
        $data = array(
                'main_content' => 'admin/user/profile',
                'recordData'   => $this->user_model->getAllUsers() 
           );

        $this->load->view(BACKEND_TEMPLATE,$data);
    }

    public function viewprofile($id = ''){
        $data = array(
                'main_content' => 'admin/user/profileview',
                'recordData'   => $this->user_model->getByUserId($id),    
            );

        $this->load->view(BACKEND_TEMPLATE,$data);
    }
}//Controller Close