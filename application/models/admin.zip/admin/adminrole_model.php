<?php 
	class Adminrole_model extends CI_Model{
		public function __construct(){
			parent:: __construct();
		}

		public function getAllData(){
			$sql 	= "select * from tbl_adminrole";
			$query 	= $this->db->query($sql);
			$res 	= $query->result_array();
			if($res){
				return $res;
			}else{
				return false;
			}
		}

		public function getById($id){
			$sql 	= "select * from tbl_adminrole where id = $id";
			$query  = $this->db->query($sql);
			$res 	= $query->row_array();
			if($res)
				return $res;
			else 
				return false;
		}

		public function add(){
				if(isset($_POST['access']))
					$access = join(',',$_POST['access']);
				if(isset($_POST['admin']))
					$admin_id = $_POST['admin'];
				if(isset($_POST['name']))
					$role_name = $_POST['name'];

			$data = array(
				'role_name' => $this->input->post('name',true),
				'admin_id'	=> $this->input->post('admin',true),
				'access'	=> isset($access)?$access:'',
				'status'	=> $this->input->post('status',true),
			);

			$q = $this->db->insert('tbl_adminrole',$data);
			if($q){
				$this->db->where('id', $admin_id);
				$this->db->update('tbl_admin',array('role'=>$role_name));
			}
		}
		
		public function edit($id){
				if(isset($_POST['access']))
					$access = join(',',$_POST['access']);
				if(isset($_POST['admin']))
					$admin_id = $_POST['admin'];
				if(isset($_POST['name']))
					$role_name = $_POST['name'];
				if(isset($_POST['admin_id']))
					$admin_id = $_POST['admin_id'];

			$data = array(
				'role_name' => $this->input->post('name',true),
				'admin_id'	=> $this->input->post('admin',true),
				'access'	=> isset($access)?$access:'',
				'status'	=> $this->input->post('status',true),
			);

			$this->db->delete('tbl_adminrole',array('admin_id'=>$admin_id));

			$q = $this->db->insert('tbl_adminrole',$data);
			if($q){
				$this->db->where('id', $admin_id);
				$this->db->update('tbl_admin',array('role'=>$role_name));
			}

		}

		public function delete($id){
			$this->db->delete('tbl_adminrole',array('id'=>$id));
		}
	}
?>