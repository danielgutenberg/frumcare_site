<?php
class Common_care_model extends CI_Model
{
      public function sort($per_page,$latitude,$longitude,$option,$account_category,$care_type){                                
        $order_type = 'asc';
        if($option == 'tbl_userprofile.id'){
            $order_type = 'desc';
        }
        $distance = 50;
        $sql = "SELECT tbl_user.*,(((acos(sin(($latitude * pi() /180 )) * sin((`lat` * pi( ) /180 ) ) + cos( ( $latitude * pi( ) /180 ) ) * cos( (`lat` * pi( ) /180 )) * cos( (( $longitude - `lng` ) * pi( ) /180 )))) *180 / pi( )) *60 * 1.1515) AS distance,tbl_userprofile.* FROM tbl_user LEFT OUTER JOIN tbl_userprofile ON tbl_user.id = tbl_userprofile.user_id  WHERE tbl_userprofile.account_category = $account_category and tbl_user.status = 1 and tbl_userprofile.profile_status = 1 ";
        if($care_type!=''){
            $sql.=" and tbl_userprofile.care_type = $care_type";
        }
        $sql.=" having distance <$distance order by $option $order_type limit 0,$per_page";        
        $query = $this->db->query($sql);
        if($query){
            return $query->result_array();
        }
        else{
            return false;
        }
    }
    public function paginate($position,$item_per_page,$latitude,$longitude,$option,$account_category,$care_type){
        $order_type = 'asc';
        if($option == 'tbl_userprofile.id'){
            $order_type = 'desc';
        }
        $distance = 50;
        $sql = "SELECT tbl_user.*,(((acos(sin(($latitude * pi() /180 )) * sin((`lat` * pi( ) /180 ) ) + cos( ( $latitude * pi( ) /180 ) ) * cos( (`lat` * pi( ) /180 )) * cos( (( $longitude - `lng` ) * pi( ) /180 )))) *180 / pi( )) *60 * 1.1515) AS distance,tbl_userprofile.* FROM tbl_user LEFT OUTER JOIN tbl_userprofile ON tbl_user.id = tbl_userprofile.user_id  WHERE tbl_userprofile.account_category = $account_category and tbl_user.status = 1 and tbl_userprofile.profile_status = 1 ";
        if($care_type!=''){
            $sql.=" and tbl_userprofile.care_type = $care_type";
        }
        $sql.=" having distance < $distance order by $option $order_type limit $position,$item_per_page";
        $query = $this->db->query($sql);
        if($query){
            return $query->result_array();
        }
        else{
            return false;
        }
    }
    public function getCount($latitude,$longitude,$account_category,$care_type){        
        $distance = 50;
        $sql = "SELECT tbl_user.*,(((acos(sin(($latitude * pi() /180 )) * sin((`lat` * pi( ) /180 ) ) + cos( ( $latitude * pi( ) /180 ) ) * cos( (`lat` * pi( ) /180 )) * cos( (( $longitude - `lng` ) * pi( ) /180 )))) *180 / pi( )) *60 * 1.1515) AS distance,tbl_userprofile.* FROM tbl_user LEFT OUTER JOIN tbl_userprofile ON tbl_user.id = tbl_userprofile.user_id  WHERE tbl_userprofile.account_category = $account_category and tbl_user.status = 1 and tbl_userprofile.profile_status = 1 ";
        if($care_type!=''){
            $sql.=" and tbl_userprofile.care_type = $care_type";
        }
        $sql.=" having distance < $distance ";        
        $query = $this->db->query($sql);        
        return $query->num_rows();
                
    }
}