<div class="container">
    <div class="padding-10">
        <div class="row">
               <span class="error">
                    <h3><?php if($this->session->flashdata('info')){ echo $this->session->flashdata('info'); } ?></h3>
                </span>
               <?php $action = $this->uri->segment(3);?>
                   <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                   <div class="panel-heading">
                    <h1 class="txt-color-blueDark">Send Notification </h1>
                    </div>
                    <div class="panel-collapse collapse in">
                    <div class="panel-collapse collapse in panel-body">
                    <?php
                        $id                  = $editData['id'];
                        $notification_type   = $editData['notification_type'];
                    ?>
                    <div class="ad-manager">
                    <form role="form" action="<?php echo site_url();?>admin/notification/send/<?php echo $id;?>" method="post" enctype="multipart/form-data" id="admin_add_edit_form">

                        <div class="form-group">
                            <label class="control-label">Notification Recepients</label>
                            <div class="ad-manager-select">
                               <div class="ad-manager-full-inputs">
                                <input type="text" class="form-control required receivers" name="notification_recepients" value="" placeholder="please enter user id or email address"/>
                               </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Notification Type</label>
                            <div class="ad-manager-select">
                                <select class="form-control required" name="notification_type">
                                    <option>--select--</option>
                                    <option value="Ad Refresh" <?php if($notification_type == 'Ad Refresh'){?> selected="selected" <?php } ?> >Ad Refresh</option>
                                    <option value="Upgrade Account" <?php if($notification_type == 'Upgrade Account'){?> selected="selected" <?php } ?>>Upgrade Account</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label">Group</label>
                            <div class="ad-manager-select">
                                <div><input type="checkbox" name="group[]" value="1">Caregivers</div>
                                <div><input type="checkbox" name="group[]" value="2">Careseekers</div>
                            </div>
                        </div>

                         <div class="form-group">
                             <div class="ad-manager-btns">
                                <input type="submit" class="btn btn-default  btn-primary" id="btn_save" name="save_admin_info" value="Send"/> 
                            </div>
                        </div>
                    
                        <div class="form-group">
                            <label class="control-label">Action</label>
                            <div class="ad-manager-btns">
                              <a href="#">Set as recurring notification</a>
                              <a href="<?php echo site_url();?>admin/notification/add">Create a notification</a>
                              <a href="<?php echo site_url();?>admin/notification/edit/<?php echo $id;?>">Edit notification</a>
                            </div>
                        </div>

                       </form>

                </div>
                    </div>
                    </div>
                </div><!--panel default-->
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('.receivers').keyup(function(){
            var receivers  = $('.receivers').val();
        });
    });
</script>