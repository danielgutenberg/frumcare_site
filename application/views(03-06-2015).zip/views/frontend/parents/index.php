<div class="container">
	<?php $this->load->view('frontend/caregivers/left_navbar.php');?>
</div>