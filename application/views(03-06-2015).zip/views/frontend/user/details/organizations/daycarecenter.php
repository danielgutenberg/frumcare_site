<?php
$cross = "<img src='".site_url()."img/cross.png'>";
$tick  = "<img src='".site_url()."img/nut-list.png'>";    
?>
<div class="table-responsive">
	<table class="table table-striped">
		<tr>
			<?php if(!empty($looking_to_work)){
				$lookingtowork = explode(',', $looking_to_work); 
				?>
				<td>For</td>
				<td>
					<div class="details-info"><?php if(in_array('Boys', $lookingtowork)){ echo $tick; }else{ echo $cross; }?>Boys</div>
					<div class="details-info"><?php if(in_array('Girls', $lookingtowork)){ echo $tick; }else{ echo $cross; }?>Girls</div>
					<div class="details-info"><?php if(in_array('Both', $lookingtowork)){ echo $tick; }else{ echo $cross; }?>Both</div>
				</td>

				<?php 
			}
			?>
		</tr>
		<tr>
			<?php if(!empty($established)){?>
			<td>Year Established </td>
			<td>
				<div class="details-info"><?php echo $established; ?></div>
			</td>

			<?php 
		}
		?>
	</tr>

	<tr>
		<?php if(!empty($certification)){?>
		<td>certification</td>
		<td>
			<div class="details-info"><?php echo $certification; ?></div>
		</td>

		<?php 
	}
	?>
</tr>

<tr>
	<?php if(!empty($age_group)){
		$agegroup = explode(',', $age_group); 
		?>
		<td>Age Group</td>
		<td>
			<div class="details-info"><?php if(in_array('0-3', $agegroup)){ echo $tick; }else{ echo $cross; }?>0-3 Months</div>
			<div class="details-info"><?php if(in_array('3-6', $agegroup)){ echo $tick; }else{ echo $cross; }?>3-6 Months</div>
			<div class="details-info"><?php if(in_array('6-12', $agegroup)){ echo $tick; }else{ echo $cross; }?>6-12 Months</div>
			<div class="details-info"><?php if(in_array('1-3', $agegroup)){ echo $tick; }else{ echo $cross; }?>1-3 Years</div>
			<div class="details-info"><?php if(in_array('3-5', $agegroup)){ echo $tick; }else{ echo $cross; }?>3-5 Years</div>
			<div class="details-info"><?php if(in_array('6-11', $agegroup)){ echo $tick; }else{ echo $cross ;}?>6-11 Years</div>
			<div class="details-info"><?php if(in_array('12+', $agegroup)){ echo $tick; }else{ echo $cross ;}?>12+ Years</div>
		</td>

		<?php 
	}
	?>
</tr>

<tr>
	<?php if(!empty($language)){
		$lang = explode(',', $language); 
		?>
		<td>Language spoken</td>
		<td>
			<div class="details-info"><?php if(in_array('English', $lang)){ echo $tick; }else{ echo $cross; }?>English</div>
			<div class="details-info"><?php if(in_array('Yiddish', $lang)){ echo $tick; }else{ echo $cross; }?>Yiddish</div>
			<div class="details-info"><?php if(in_array('Hebrew', $lang)){ echo $tick; }else{ echo $cross; }?>Hebrew</div>
			<div class="details-info"><?php if(in_array('Russian', $lang)){ echo $tick; }else{ echo $cross; }?>Russian</div>
			<div class="details-info"><?php if(in_array('French', $lang)){ echo $tick; }else{ echo $cross; }?>French</div>
			<div class="details-info"><?php if(in_array('Other', $lang)){ echo $tick; }else{ echo $cross; }?>Other</div>
		</td>

		<?php 
	}
	?>
</tr>
<tr>
	<?php if(!empty($number_of_children)){?>
	<td>Number of children in group</td>
	<td><?php echo $number_of_children;?>
		<?php }?>
	</tr>

	<tr>
		<?php if(!empty($number_of_staff)){?>
		<td>Number of staff</td>
		<td><?php echo $number_of_staff;?>
			<?php }?>
		</tr>

		<tr>
			<?php if(!empty($rate)){?>
			<td>Cost</td>
			<td><?php echo $rate;?>
				<?php }?>
			</tr>


			<tr>
				<td>Days/ Hours</td>
				<?php if(!empty($sunday_from) || !empty($sunday_to)){ ?>
				<td>Sun <?php echo $sunday_from;?>- <?php echo $sunday_to;?></td>
				<?php } ?>
			</tr>

			<tr>
				<?php if(!empty($mid_days_from) || !empty($mid_days_to)){ ?>
				<td></td>
				<td>Mon-Thu <?php echo $mid_days_from;?>- <?php echo $mid_days_to;?></td>
				<?php } ?>
			</tr>

			<tr>
				<?php if(!empty($friday_from) || !empty($friday_to)){ ?>
				<td></td>
				<td>Fri <?php echo $friday_from;?>- <?php echo $friday_to;?></td>
				<?php } ?>
			</tr>
			<tr>
				<?php if(isset($extended_hrs)){?>
				<td></td>
				<td><?php if($extended_hrs == 1){?> Available on Extended Hours<?php }?></td>
				<?php } ?>
			</tr>

			<tr>
				<?php if(isset($flexible_hours)){?>
				<td></td>
				<td><?php if($flexible_hours == 1){?> Available on Flexible Hours<?php }?></td>
				<?php } ?>
			</tr>

			<tr>
				<?php if(!empty($vacation_days)){?>
				<td></td>
				<td>
					<?php echo $vacation_days;?>
					<?php if(!empty($pdf)){?>
					<a href="<?php echo site_url();?>uploads/files/<?php echo $pdf;?>" target="_blank"> Click here to view/Download</a>
					<?php } ?>
				</td>
				<?php } ?>
			</tr>
			<tr>
				<?php if(!empty($profile_description)){?>
				<td>Organization/facilities/activities</td>
				<td><?php echo $profile_description;?></td>
				<?php } ?>
			</tr>

			<tr>
				<?php if(isset($references)){?>
				<?php if($references == 1){?>
				<td>Refrences</td>
				<td>
					<a href="<?php echo site_url();?>uploads/files/<?php echo $reference_file;?>" target="_blank"> Click here to view/Download</a>
				</td>
				<?php 
			}
		}
		?>
	</tr>


</table>
</div>