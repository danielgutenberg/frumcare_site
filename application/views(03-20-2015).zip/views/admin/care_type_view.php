<form action="" method="post">
    <input type="text" name="service_name" autofocus="">
    <select name="service_type">
        <option value="1">Caregiver</option>
        <option value="2">Careseeker</option>
    </select>
    <select name="service_by">
        <option value="2">Organization</option>
        <option value="1">Individual</option>
    </select>
    <input type="submit" value="Save">
</form>