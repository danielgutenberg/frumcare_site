<div class="container">
    <div class="sign_up_successful">
    <h2>Welcome to the Frumcare family.</h2> 
    <p>Your account has been successfully created. You need to verify your email. Please follow the link in the email  to verify your email address.</p>
    <p><a href="">Click Here</a> to resend the email.</p>
    <p><?php 
            if(is_array($redirectData))
                $link = site_url().'ad/add_step2/'.$redirectData['account_cat'].'/'.$redirectData['account_type'].'/'.$this->session->userdata('log_id') ;
            else
                $link = site_url().'user/profile';
        ?></p>
    <p><a href="<?php echo $link;?>">Click Here</a> to post an ad.</p>
    <p>Thanks!</p>
    </div>
</div>
