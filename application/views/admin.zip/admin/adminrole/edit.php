<div class="container">
    <div class="padding-10">
        <div class="row">
               <span class="error">
                    <h3><?php if($this->session->flashdata('info')){ echo $this->session->flashdata('info'); } ?></h3>
                </span>
               <?php $action = $this->uri->segment(3);?>
                   <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                   <div class="panel-heading">
                    <h1 class="txt-color-blueDark"><?php if($action=='add'){echo "Add";}else{echo "Edit";}?> Admin Role Details</h1>
                    </div>
                    <div class="panel-collapse collapse in">
                    <div class="panel-collapse collapse in panel-body">
                    <?php
                    if($action=='edit')
                    {   
                        $id        = $editData['id'];
                        $role_name = $editData['role_name'];
                        $admin_id  = $editData['admin_id'];
                        $access    = explode(',' ,$editData['access']);
                        $status    = $editData['status'];
                    }
                    else{
                        $id='';
                    }
                    ?>
                    <div class="ad-manager">
                    <form role="form" action="<?php echo site_url('admin/adminrole/edit');?>" method="post" enctype="multipart/form-data" id="admin_add_edit_form">
                         <div class="form-group">
                            <label class="control-label">Admin Role</label>
                            <div class="ad-manager-full-input"><input type="text" class="form-control required" name="name" value="<?php if(isset($role_name)){ echo $role_name;} ?>" /></div>
                        </div>

                        <div class="form-group">
                            <label class="control-label">User</label>
                            <div class="ad-manager-select">
                                <select class="form-control required" name="admin">
                                    <option>--select--</option>
                                    <?php 
                                        if(is_array($adminusers)){
                                            foreach ($adminusers as $key => $value):
                                        ?>
                                        <option value="<?php echo $value['id'];?>" <?php if($admin_id == $value['id']){?> selected="selected" <?php }?>>
                                            <?php echo ucwords($value['full_name']);?>
                                       </option>
                                        <?php 
                                            endforeach;
                                         } 
                                        ?>
                                </select>
                            </div>
                        </div>

                         <div class="form-group">
                            <label class="control-label">Admin Privilege</label>    
                            <div class="ad-manager-full-input">
                                <input type="checkbox" name="access[]" value="accept_payment" <?php if(in_array('accept_payment',$access)){?> checked="checked" <?php }?> > Accept Payment
                                <input type="checkbox" name="access[]" value="acceptandrejectad" <?php if(in_array('acceptandrejectad',$access)){?> checked="checked" <?php }?> > Accept and reject Advertisement
                                <input type="checkbox" name="access[]" value="replyticket" <?php if(in_array('replyticket',$access)){?> checked="checked" <?php }?> > Reply Ticket 
                            </div>
                        </div>
                     
                     	 <div class="form-group">
                        	<label class="control-label">Status</label>
                        	<div class="ad-manager-select">
                        		<select class="form-control required" name="status">
                            		<option>--select--</option>
                            		<option value="1" <?php if($status == 1){?> selected="selected" <?php }?> >Active</option>
                                    <option value="0" <?php if($status == 0){?> selected="selected" <?php }?> >Inactive</option>
                        		</select>
                        	</div>
                    	</div>

                         <div class="form-group">
                             <div class="ad-manager-btns">
                            <?php if(isset($id)){ ?><input type="hidden" name="id" value="<?php echo $id; ?>" /><?php }?>
                            <?php if(isset($admin_id)){ ?><input type="hidden" name="adminid" value="<?php echo $admin_id; ?>" /><?php }?>
                            <input type="submit" class="btn btn-default  btn-primary" id="btn_save" name="save_admin_info" value="Save"/> 
                            
                            </div>
                        </div>
                    </form>
                </div>
                    </div>
                    </div>
                </div><!--panel default-->
            </div>
        </div>
    </div>
</div>
<script>    
    $('#admin_add_edit_form').validate();
</script>
