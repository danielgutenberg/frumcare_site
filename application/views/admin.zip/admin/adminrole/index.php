
<div class="">
    <div class="padding-10">
        <div class="row">
            <div class="">
                <?php flash();?>
                <!--Admin Details Manager-->
                <div class="panel-group" id="accordion">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h1 class="txt-color-blueDark">
                        <i class="fa fa-lg fa-fw fa-user"></i> <span>AdminRole Manager</span>
                        
                       </h1>
                    </div>
                    <div id="collapseTwo" class="panel-collapse collapse in">
                      <div class="panel-body">
                        <div class="table-responsive">
                            <table class="table table-hover table-bordered sortable_tbl">
                                <div class="dt-top-row"><div id="dt_basic_length" class="dataTables_length"><span class="smart-form"><label style="width:60px" class="select"><select name="dt_basic_length" size="1" aria-controls="dt_basic"><option value="10" selected="selected">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select><i></i></label></span></div><div class="dataTables_filter" id="dt_basic_filter"><div class="input-group"><span class="input-group-addon"><i class="fa fa-search"></i></span><input type="text" placeholder="Filter" class="form-control" aria-controls="dt_basic"></div></div>
                                <thead>
                                    <tr class="">
                                        <th>Admin Role</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if($data!=null){
                                        foreach($data as $admins){
                                            ?>
                                            <tr>
                                                <td><?php echo ucwords($admins['role_name']);?></td>
                                                <td>
                                                    <?php 
                                                        if($admins['status'] == 0){
                                                            echo 'Inactive';
                                                        }
                                                        if($admins['status'] == 1){
                                                            echo 'Active';
                                                        } 
                                                    ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo site_url('admin/adminrole/edit')."/".$admins['id']; ?>" class="btn btn-info" title="Edit">Edit</a>
                                                    <a href="<?php echo site_url('admin/admin/delete')."/".$admins['id']; ?>" class="btn btn-danger" title="Delete" onclick="return confirm('Are you sure to delete this admin?');">Delete
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr class="warning">
                                            <th>No Data</th>
                                            <th>No Data</th>
                                            <th>No Data</th>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                </tbody>    
                            </table>
                            <div class="pull-right">
                            <a class="btn btn-success" href="<?php echo site_url('admin/adminrole/add'); ?>">Create User Type</a>
                        </div>
                        <div class="clearfix"></div>
                        <div class="text-right"><div class="dataTables_paginate paging_bootstrap_full"><ul class="pagination"><li class="first disabled"><a href="#">First</a></li><li class="prev disabled"><a href="#">Previous</a></li><li class="active"><a href="#">1</a></li><li><a href="#">2</a></li><li><a href="#">3</a></li><li><a href="#">4</a></li><li><a href="#">5</a></li><li class="next"><a href="#">Next</a></li><li class="last"><a href="#">Last</a></li></ul></div></div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            <!----------------------------Admin Details Manager Ends--------------------------->
        </div>
    </div>
</div>
</div>