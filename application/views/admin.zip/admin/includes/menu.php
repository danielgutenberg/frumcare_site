<aside id="left-panel">
      <!-- User info -->
      <div class="login-info">
          <span>
            <a href="<?php echo site_url();?>admin/admin/adminprofile/<?php echo $this->session->userdata['admin_id'];?>"><img src="<?php echo site_url("plugins/admin/img/avatars/sunny.png")?>" alt="me" class="online" /> </a>
            <a href="javascript:void(0);" id="show-shortcut">
            <?php echo ucwords($this->session->userdata['admin_username']);?> 
            <!-- <i class="fa fa-angle-down"></i> -->
          </a> 
          </span>
      </div>
      <!-- end user info -->

      <nav>

        <ul>
            <li>
                <a href="<?php echo site_url();?>admin/dashboard" title="Dashboard">Dashboard</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/page" title="Page Manager">Page Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/user" title="User Manager">User Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/user/logs" title="User Log Manager">User Log Manager</a>
            </li>
            <li>  
                <a href="<?php echo site_url();?>admin/user/profilepicture" title="User ProfilePicture Manager">User Profile Picture Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/user/profile" title="User Profile Configuration">User Profile Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/emailtemplate" title="Email Template Manager">Email Template Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/payment" title="Payment Manager">Payment Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/ad" title="Ad Manager">Ad Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/searchalert" title="Search Alert">Search Alert</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/package" title="Package Manager">Package Manager</a>
            </li>
            <li>
                <a href="<?php echo site_url();?>admin/feature" title="Feature Manager">Feature Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/ticket" title="Ticket Manager">Ticket Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/testimonial" title="Testimonial Manager">Testimonial Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/genericseo" title="General SEO Manager">General SEO Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/notification" title="Notification Manager">Notification Manager</a>
            </li>
            <li>
              <a href="<?php echo site_url();?>admin/adminrole" title="Admin Role Manager">AdminRole Manager</a>
            </li>
        </ul>
      </nav>
      <span class="minifyme"> <i class="fa fa-arrow-circle-left hit"></i> </span>

</aside>

<div id="main" role="main">

  <div id="ribbon">

        <span class="ribbon-button-alignment"> <span id="refresh" class="btn btn-ribbon" data-title="refresh"  rel="tooltip" data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true"><i class="fa fa-refresh"></i></span> </span>

        <!-- breadcrumb -->
        <ol class="breadcrumb">
          <li>Home</li><?php if(isset($title)) echo '<li>'.$title.'</li>';?>
        </ol>
        <!-- end breadcrumb -->

        <!-- You can also add more buttons to the
        ribbon for further usability

        Example below:

        <span class="ribbon-button-alignment pull-right">
        <span id="search" class="btn btn-ribbon hidden-xs" data-title="search"><i class="fa-grid"></i> Change Grid</span>
        <span id="add" class="btn btn-ribbon hidden-xs" data-title="add"><i class="fa-plus"></i> Add</span>
        <span id="search" class="btn btn-ribbon" data-title="search"><i class="fa-search"></i> <span class="hidden-mobile">Search</span></span>
        </span> -->

      </div>
      <!-- END RIBBON -->
  <div id="content">


<script type="text/javascript">
  // $(document).ready(function(){
  //   $('#show-shortcut').on(click, function(){
      
  //   });
  // });
</script>