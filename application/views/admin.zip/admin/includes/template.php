<?php echo $this->load->view('admin/includes/admin_header.php');?>
<?php echo $this->load->view('admin/includes/menu.php');?>

<?php echo $this->load->view($main_content);?>
<?php echo $this->load->view('admin/includes/admin_footer.php');?>
