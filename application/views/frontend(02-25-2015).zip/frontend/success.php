<div class="container sign_up_save">
	<h2>Success</h2>
	<p>User is successfully approved.</p>
</div>

<script type="text/javascript">
	 $(document).ready(function(){
	      setTimeout(function() {
	       window.location.href = "<?php echo base_url();?>"
	      }, 5000);
    });
</script>