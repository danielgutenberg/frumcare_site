<div class="container sign_up_save">
        <h2>Contact Form</h2>
   <form action="<?php echo site_url();?>contactprofile/profile" method="post" id="contact_form" enctype="multipart/form-data">
        <div class="contact-profile">
                <label>Name</label>
                <input type="text" name="name" class="required">
        </div>
        <div class="contact-profile">
                <label>Phone Number</label>
                <input type="text" name="phonenumber" class="required">
        </div>

        <div class="contact-profile">
            <label>Email</label>
            <input type="text" name="email" class="required"> 
        </div>


        <div class="contact-profile">
            <label>Comment</label>
            <textarea name="comment"></textarea>
        </div>

           <?php 
        if($category == 'careseekers'){?>

        <div class="contact-profile">
            <label for='uploaded_file'>Upload Resume</label>
            <input type="file" name="userfile">
         </div>

         <?php } ?>

        <div class="contact-profile">
                <input type="submit" name="contact" value="Contact" class="btn btn-primary">
        </div>
   </form>
</div>
<script type="text/javascript">
$(document).ready(function(){
    $('#contact_form').validate({
        rules: {
            email: {
                    required: true,
                    email: true
                    },
        },
         messages: {
                    email: "Please enter a valid email address",
                },
    });
})
</script>