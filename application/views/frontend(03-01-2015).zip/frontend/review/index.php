<div class="container reviews-wrappers">
	<div class="reviews-wrappers">
<?php 
	if($recordData):
		foreach($recordData as $data):
?>
	<div class="review_details">
		<p><?php echo nl2br($data['description']);?></p>
		<span class="name"><?php echo $data['name'];?></span>
		<br />
		<span class="date"><?php echo $data['created_date'];?></span>
	</div>
<?php 
		endforeach;
	endif;
?>
</div>
</div>
