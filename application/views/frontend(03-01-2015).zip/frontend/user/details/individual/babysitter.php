<!-- Start Babysitter-->    
    <?php
    if(!empty($looking_to_work)){?>
    <div class="form-group">
    	<label >Looking to work in</label>
    	<div >            
            <?php process($looking_to_work); ?>		
    	</div>
    </div>
    <?php }
    if(!empty($number_of_children)){?>
    <div class="form-group">
	   <label >Number of children willing to care for</label>
	   <div class="ad-manager-full-input">
            <?php echo $number_of_children ?>
       </div>
    </div>
    <?php }
    if(!empty($optional_number)){?>
    <div class="from-group">    	
    	<div >    		
            <?php process($optional_number); ?>        
    	</div>
    </div>
    <?php }
    if(!empty($age_group)){?>
    <div class="form-group">
    	<label >Ages of children willing to care for</label>
    	<div >    		
            <?php process($age_group); ?>             
        </div>
    </div>
    <?php }
    if(!empty($experience)){?>
    <div class="form-group">
    	<label >Years of experience</label>
    	<div class="ad-manager-full-input">    		
            <?php echo $experience; ?>  
    	</div>
    </div>
    <?php }
    if(!empty($training)){?>
    <div class="form-group">
    	<label >Training (check one or more)</label>
    	<div >
                <?php process($training); ?>                       
    	</div>	
    </div>
    <?php }
    if(!empty($rate)){?>
    <div class="form-group">
    	<label >Rate</label>
    	<div class="ad-manager-full-input">
            <?php echo $rate ?>
            <?php echo $rate_type==1?" per hour":"per month"; ?>    
    	</div>
    </div>
    <?php }
    if(!empty($availablility)){?>
    <div class="form-group">
    	<label >Availability (check one or more)</label>
    	<div >
                <?php process($availablility); ?>            
    	</div>
    </div>
    <?php }
    if(!empty($references)){?>
    <div class="form-group">
    	<label >References</label>
    	<div >
    		<a href="">Download</a>
    	</div>
    </div>
    <?php } ?>    
    <div class="form-group">
    	<label >Abilities and skills</label>
        <div >
            <?php
            if(!empty($driver_license)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($driver_license) && $driver_license == 1 ? 'I have a drivers license' : ''?></div>
            <?php }
            if(!empty($vehicle)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($vehicle) && $vehicle == 1 ? 'I have a vehicle' : ''?></div>
            <?php }
                if(!empty($pick_up_child)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($pick_up_child) && $pick_up_child == 1 ? 'Able to pick up kids from school' : ''?></div>
            <?php }
                if(!empty($cook)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($cook) && $cook == 1 ? 'Able to cook and prepare food' : ''?></div>
            <?php }
            if(!empty($basic_housework)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($basic_housework) && $basic_housework == 1 ? 'Able to do light housework/ cleaning' : ''?></div>
            <?php }
            if(!empty($homework_help)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($homework_help) && $homework_help == 1 ? 'Able to help with homework' : ''?></div>
            <?php }
            if(!empty($sick_child_care)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($sick_child_care) && $sick_child_care == 1 ? 'Able to care for sick child' : ''?></div>
            <?php }
            if(!empty($on_short_notice)){?>
            <div class="checkbox" ><input type="checkbox" checked="checked"/><?php echo isset($on_short_notice) && $on_short_notice == 1 ? 'Available on short notice' : ''?></div>
            <?php }?>
        </div>
    </div>
    
<!-- end Babysitter-->
