   <?php
    if(!empty($looking_to_work)){?>
    <div class="form-group">
    	<label >Looking to work in</label>
    	<div >            
            <?php process($looking_to_work); ?>		
    	</div>
    </div>
    <?php }
    if(!empty($number_of_children)){?>
    <div class="form-group">
	   <label >Number of children willing to care for</label>
	   <div class="ad-manager-full-input">
            <?php echo $number_of_children ?>
       </div>
    </div>
    <?php }
      if(!empty($optional_number)){?>
    <div class="from-group">    	
    	<div >    		
            <?php process($optional_number); ?>        
    	</div>
    </div>
    <?php }
 if(!empty($age_group)){?>
    <div class="form-group">
    	<label >Ages of children willing to care for</label>
    	<div >    		
            <?php process($age_group); ?>             
        </div>
    </div>
    <?php }
    if(!empty($experience)){?>
    <div class="form-group">
    	<label >Years of experience</label>
    	<div class="ad-manager-full-input">    		
            <?php echo $experience; ?>  
    	</div>
    </div>
    <?php }
  if(!empty($training)){?>
    <div class="form-group">
    	<label >Training (check one or more)</label>
    	<div >
                <?php process($training); ?>                       
    	</div>	
    </div>
    <?php }
    if(!empty($rate)){?>
    <div class="form-group">
    	<label >Rate</label>
    	<div class="ad-manager-full-input">
            <?php echo $rate ?>
            <?php echo $rate_type==1?" per hour":"per month"; ?>    
    	</div>
    </div>
    <?php }
  if(!empty($availablility)){?>
    <div class="form-group">
    	<label >Availability (check one or more)</label>
    	<div >
                <?php process($availablility); ?>            
    	</div>
    </div>
    <?php }
    if(!empty($references)){?>
    <div class="form-group">
    	<label >References</label>
    	<div >
    		<a href="">Download</a>
    	</div>
    </div>
    <?php } ?>
<div class="form-group">
	<label >Abilities and Skills</label>
	<div >
		<?php
            if($driver_license == 1){?>
        <input type="checkbox" checked="checked">I have a drivers license<br/>
		<?php }
            if($vehicle == 1){?>
        <input type="checkbox" checked="checked">I have a vehicle<br/>
		<?php }
            if($pick_up_child == 1){?>
        <input type="checkbox" checked="checked">Able to pick up kids from school<br/>
		<?php }
            if($cook == 1){?>
        <input type="checkbox" checked="checked">Able to cook and prepare food<br/>
		<?php }
            if($basic_housework == 1){?>
        <input type="checkbox" checked="checked">Able to do housework/ cleaning<br/>
		<?php }
            if($homework_help == 1){?>
        <input type="checkbox" checked="checked">Able help with homework<br/>        
		<?php }
            if($bath_children == 1){?>
        <input type="checkbox" checked="checked">Able to bathe children<br />
		<?php }
            if($bed_children == 1){?>
        <input type="checkbox" checked="checked">Able to put children to bed<br />
        <?php }
            if($sick_child_care == 1){?>
        <input type="checkbox" checked="checked">Able to care for sick child<br/>
        <?php }
            if($on_short_notice == 1){?>
        <input type="checkbox" checked="checked">Available on short notice<br/>
        <?php }?>        
    </div>
</div>
