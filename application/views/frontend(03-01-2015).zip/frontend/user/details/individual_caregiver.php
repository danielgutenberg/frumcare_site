 <?php
    function process($data){
        if(!empty($data)){
            $x = explode(',',$data);
            foreach($x as $y){
                echo '<div class="checkbox"><input type="checkbox" checked="checked">'.$y.'</div>';
            }
        }        
    }
 ?>
 <div class="container">
        <h2>
            Personal Details 
        </h2>
    <?php if(!empty($location)){?>
    <div>
        <label>Location</label>
        <div id="locationField">
            <?php echo $location;?>
        </div>    
    </div>
    <?php }?>
    <?php if(!empty($neighbour)){?>
    <div>
        <label>Neighbourhood</label>
        <div>
            <?php echo $neighbour;?>
        </div>    
    </div>
    <?php }?>
    <?php if(!empty($zip)){?>
    <div>
        <label>Zip</label>
        <div><?php echo $zip;?> </div>
    </div>
    <?php }?>
     <?php 
     /*
     if(!empty($contact_number)){?>
     <div>
        <label>Phone</label>
        <div class="form-field">
        <?php echo $contact_number;?>
        </div>
    </div>
    <?php } */?>
    <?php if(!empty($age)){?>
    <div>
        <label>Age</label>
        <div class="form-field">
        <?php echo $age;?>
        </div>
    </div>
    <?php }?>
    <?php if(!empty($gender)){?>
    <div>
        <label>Gender</label>
        <div class="form-field">
          <?php echo $gender==1?'Male':'Female'?>
        </div>
    </div>
    <?php }?>
    <?php if(!empty($marital_status)){?>
    <div>
        <label>Marital status</label>
        <div class="form-field">
            <?php 
            if($marital_status==1){
                echo "Single";
            }
            else if($marital_status==2){
                echo "Married";
            }
            else if($marital_status==3){
                echo "Divorced";
            }else{
                echo "Widowed";
            }?>            
        </div>
    </div>
    <?php }?>
    <?php if(!empty($language)){?>
    <div>
        <label>Languages spoken</label>
        <div class="form-field">            
            <?php 
                $lang = explode(',',$language);
                foreach($lang as $lg){
                    echo '<div class="checkbox"><input type="checkbox" checked="checked">'.$lg.'</div>';
                }
            ?>
        </div>
    </div>
    <?php }?>
    <?php if($smoker==1 || $smoker==3){?>
    <div>
        <label>Smoker</label>
        <div class="form-field">        
        <?php echo "Yes"?>
        </div>
    </div>
    <?php }?>
    <?php if(!empty($religious_observance)){?>
    <div>
        <label>Level of religious observance</label>
        <div class="form-field">
        <?php echo $religious_observance?>
        </div>
    </div>
    <?php }?>    
    <?php if(!empty($education_level)){?>
    <div>
        <label>Level of education</label>
        <div class="form-field">
            <?php 
                $education_level = explode(',',$education_level);
                foreach($education_level as $el){
                    echo '<div class="checkbox"><input type="checkbox" checked="checked">'.$el.'</div>';
                }
            ?>
        </div>
    </div>
    <?php }?>
    <?php if(!empty($educational_institution)){?>
    <div>
        <label>Educational institutions attended</label>
        <div class="form-field">
            <?php echo $educational_institution; ?>
        </div>
    </div>
    <?php }?>
    <div>
        <h2>Job Details</h2>
    </div>
    <?php
        if($care_type==1){
            $this->load->view('frontend/user/details/individual/babysitter');
        }
        else if($care_type==2){
            $this->load->view('frontend/user/details/individual/nanny');
        }
        else if($care_type==3){
            $this->load->view('frontend/user/details/individual/nursery');
        }
        else if($care_type==4){
            $this->load->view('frontend/user/details/individual/tutor');
        }
        else if($care_type==5){
            $this->load->view('frontend/user/details/individual/senior_caregiver');
        }
        else if($care_type==6){
            $this->load->view('frontend/user/details/individual/special_needs_caregiver');            
        }
        else if($care_type==7){
            $this->load->view('frontend/user/details/individual/therapist');
        }
        else if($care_type==8){
            $this->load->view('frontend/user/details/individual/cleaning');        
        }
        else{
            $this->load->view('frontend/user/details/individual/errand_runner');
        }
    ?>
</div><!-- end main-->