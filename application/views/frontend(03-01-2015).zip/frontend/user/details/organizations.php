<div class="container">    
       <h2>Organization info</h2>
    <?php if(!empty($location)){?>
    <div>
        <label>Location</label>
        <div id="locationField">
            <?php echo $location;?>
        </div>    
    </div>
    <?php }
    if(!empty($neighbour)){?>
    <div>
        <label>Neighbourhood</label>
        <div>
            <?php echo $neighbour;?>
        </div>    
    </div>
    <?php }
    if(!empty($zip)){?>
    <div>
        <label>Zip</label>
        <div><?php echo $zip;?> </div>
    </div>
    <?php }
    /*
    if(!empty($contact_number)){?>
     <div>
        <label>Phone</label>
        <div class="form-field">
            <?php echo $contact_number;?>
        </div>
    </div>
    <?php }
    */
    if(!empty($name_of_owner)){?>
    <div>
        <label>Name of owner/ operator</label>
        <div class="form-field">
            <?php echo $name_of_owner; ?>
        </div>
    </div>
    <?php }
    if(!empty($age)){?>

    <div>
        <label>Age of owner/ operator</label>
        <div class="form-field">
            <?php echo $age; ?>    
        </div>
    </div>
    <?php }
    if(!empty($gender)){?>
     <div>
        <label>Gender</label>
        <div class="form-field">
            <?php echo $gender==1?"Male":"Female"; ?>
        </div>
    </div>
    <?php }
    if(!empty($religious_observance)){?>
    <div> 
        <label>Level of religious observance</label>
        <div class="form-field">
            <?php echo $religious_observance?>
        </div>
    </div>
    <?php } ?>
</div>