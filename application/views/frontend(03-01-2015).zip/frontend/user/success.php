<div class="container">
	<h2>Success</h2>
	<p> Your email has been successfully verified.</p>
</div>