<div class="container">
	<?php echo $this->breadcrumbs->show();?>

	<h2>Success</h2>
	<p>The ad has been approved.</p>
</div>