<?php 
	print_r($data);

?>