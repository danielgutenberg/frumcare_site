<div>
    <p>Hi There,</p>
    <p>
        Recently you made a request to change your FrumCare account password. Please follow the link below to
        change you password.
    </p>
    <p>
        <a class="btn btn-success btn-large" href="<?php echo site_url('login/changepassword/'.$hash.'?hash='.sha1('jesus')) ?>">Change Password</a>
    </p>
    <p>
        Thanks<br/>FrumCare.com
    </p>
</div>