<?php echo $this->load->view('frontend/includes/header.php');?>
<?php echo $this->load->view($main_content);?>
<?php echo $this->load->view('frontend/includes/footer.php');?>
