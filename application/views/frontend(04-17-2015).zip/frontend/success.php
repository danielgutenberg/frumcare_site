<div class="container">
	<div class="sign_up_successful">
		<h2>Success</h2>
		<p>User is successfully approved.</p>
	</div>
</div>

<script type="text/javascript">
	$(document).ready(function(){
		setTimeout(function() {
			window.location.href = "<?php echo base_url();?>"
		}, 5000);
	});
</script>