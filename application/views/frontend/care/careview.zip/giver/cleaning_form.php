<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Your Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>

<div class="container">
    <form action="<?php echo site_url();?>ad/savejobdetails" method="post">
        <div class="ad-form-container">
            <div>
                <h1 class="step3">Step 3: Job Details</h1>
            </div>
            <div>
                <label>Looking to work in (check one or more)</label>
                <div class="form-field">
                <div class="first-block-checkbox"><div><input type="checkbox" value="Private home" name="looking_to_work[]"> <span>Private home</span></div>
                <div><input type="checkbox" value="Office" name="looking_to_work[]"> <span>Office</span></div></div>
                <div class="first-block-checkbox"><div><input type="checkbox" value="Cleaning company" name="looking_to_work[]"> <span>Cleaning company</span></div>
                </div>
                </div>
            </div>
            <div>
                <label>Years of experience</label>
                <div class="form-field">
                <select name="experience" class="required">
                    <option value="">Select years of experience</option>
                    <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                    <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                    <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                    <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                    <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
                </select>
                </div>
            </div>
            <div>
                <label>Rate</label>
                <div class="form-field">
                <select name="hourly_rate" class="required">
                <option value="">Select rate</option>
                <option value="5-10" <?php echo isset($hr_rate) && $hr_rate == '5-10' ? 'selected' : '' ?>>$5-$10</option>
                <option value="10-15" <?php echo isset($hr_rate) && $hr_rate == '10-15' ? 'selected' : '' ?>>$5-$10</option>
                <option value="15-25" <?php echo isset($hr_rate) && $hr_rate == '15-25' ? 'selected' : '' ?>>$15-$25</option>
                <option value="25-35" <?php echo isset($hr_rate) && $hr_rate == '25-35' ? 'selected' : '' ?>>$25-$35</option>
                <option value="35-45" <?php echo isset($hr_rate) && $hr_rate == '35-45' ? 'selected' : '' ?>>$35-$45</option>
                <option value="45-55" <?php echo isset($hr_rate) && $hr_rate == '45-55' ? 'selected' : '' ?>>$45-$55</option>
                <option value="55+" <?php echo isset($hr_rate) && $hr_rate == '55+' ? 'selected' : '' ?>>$55+</option>
                </select>
                </div>
            </div>

            <div>
                <label>Specialize in</label>
                <div class="form-field">
                    <div class="first-block-checkbox">
                <div><input type="checkbox" value="Floors" name="willing_to_work[]"> <span>Floors</span></div>
                <div><input type="checkbox" value="Windows" name="willing_to_work[]"> <span>Windows</span></div>
                </div>
                <div class="first-block-checkbox">
                <div><input type="checkbox" value="Dishes" name="willing_to_work[]"> <span>Dishes</span></div>
                <div><input type="checkbox" value="Laundry" name="willing_to_work[]"> <span>Laundry</span></div>
                </div>
                <div class="first-block-checkbox">
                <div><input type="checkbox" value="Wash" name="willing_to_work[]"> <span>Wash</span></div>
                <div><input type="checkbox" value="Fold" name="willing_to_work[]"> <span>Fold</span></div>
                </div>
                <div class="first-block-checkbox">
                <div><input type="checkbox" value="Iron" name="willing_to_work[]"> <span>Iron</span></div>
                <div><input type="checkbox" value="Furniture" name="willing_to_work[]"> <span>Furniture</span></div>
                </div>
                </div>
            </div>

            <div>
                <label>Availability (check one or more)</label>
                <div class="form-field">
                    <div class="first-block-checkbox">
                    <div><input type="checkbox" value="Imm/ Start Date" name="availability[]"> <span>Imm/ Start Date</span></div>
                    <div><input type="checkbox" value="Part Time" name="availability[]"> <span>Part Time</span></div>
                    </div>
                    <div class="first-block-checkbox">
                    <div><input type="checkbox" value="Full Time" name="availability[]"> <span>Full Time</span></div>
                    <div><input type="checkbox" value="Morning" name="availability[]"> <span>Morning</span></div>
                    </div>
                    <div class="first-block-checkbox">
                    <div><input type="checkbox" value="Afternoon" name="availability[]"> <span>Afternoon</span></div>
                    <div><input type="checkbox" value="Evening" name="availability[]"> <span>Evening</span></div>
                    </div>
                    <div class="first-block-checkbox">
                    <div><input type="checkbox" value="Weekends/ Shabbos" name="availability[]"> <span>Weekends/ Shabbos</span></div>
                </div>/
                </div>
            </div>
            <br />
            <div>
                <input type="submit" class="btn btn-success" value="Save & Continue"/>
            </div>
        </div>
    </form>
</div>