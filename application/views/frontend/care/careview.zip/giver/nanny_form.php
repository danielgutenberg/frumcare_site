<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Your Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>

<div class="container">
<form action="<?php echo site_url();?>ad/savejobdetails" method="post">
    <div class="ad-form-container">
        <div>
            <h1 class="step3">Step 3: Job Details</h1>
        </div>
        <div>
            <label>Looking to work in (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="Live in" name="looking_to_work[]"> <span>Live in</span></div>
            <div><input type="checkbox" value="Live out" name="looking_to_work[]"> <span>Live out</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Any" name="looking_to_work[]"> <span>Any</span></div>
            </div>
            </div>
        </div>
        <div>
            <label>Number of children willing to care for</label>
            <div class="form-field">
            <input type="text" value="" name="number_of_children" class="required number">
            </div>
        </div>
        <div>
            <label>Ages of children willing to care for</label>
            <div class="form-field">
            <select name="age_group" class="required">
                <option value="">Select age of children</option>
                <option value="0-1" <?php echo isset($age_grp) && $age_grp == '0-1' ? 'selected' : '' ?>>First year</option>
                <option value="1-3" <?php echo isset($age_grp) && $age_grp == '1-3' ? 'selected' : '' ?>>1 to 3 years</option>
                <option value="3-5" <?php echo isset($age_grp) && $age_grp == '3-5' ? 'selected' : '' ?>>3 to 5 years</option>
                <option value="6-11" <?php echo isset($age_grp) && $age_grp == '6-11' ? 'selected' : '' ?>>6 to 11 years</option>
                <option value="12+" <?php echo isset($age_grp) && $age_grp == '6-11' ? 'selected' : '' ?>>12+ years</option>
            </select>
            </div>
        </div>
        <div>
            <label>Years of experience</label>
            <div class="form-field">
            <select name="experience" class="required">
                <option value="">Select years of experience</option>
                <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
            </select>
            </div>
        </div>
        <div>
            <label>Training (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="CPR" name="training[]"> <span>CPR</span></div>
            <div><input type="checkbox" value="First Aid" name="training[]"> <span>First Aid</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Nanny/ Babysitter Course" name="training[]"> <span>Nanny/ Babysitter Course</span></div>
            <div><input type="checkbox" value="Other" name="training[]"> <span>Other</span></div>
            </div>
            </div>
        </div>
        <div>
            <label>Rate</label>
            <div class="form-field">
            <select name="hourly_rate" class="required">
            <option value="">Select rate</option>
            <option value="5-10" <?php echo isset($hr_rate) && $hr_rate == '5-10' ? 'selected' : '' ?>>$5-$10</option>
            <option value="10-15" <?php echo isset($hr_rate) && $hr_rate == '10-15' ? 'selected' : '' ?>>$5-$10</option>
            <option value="15-25" <?php echo isset($hr_rate) && $hr_rate == '15-25' ? 'selected' : '' ?>>$15-$25</option>
            <option value="25-35" <?php echo isset($hr_rate) && $hr_rate == '25-35' ? 'selected' : '' ?>>$25-$35</option>
            <option value="35-45" <?php echo isset($hr_rate) && $hr_rate == '35-45' ? 'selected' : '' ?>>$35-$45</option>
            <option value="45-55" <?php echo isset($hr_rate) && $hr_rate == '45-55' ? 'selected' : '' ?>>$45-$55</option>
            <option value="55+" <?php echo isset($hr_rate) && $hr_rate == '55+' ? 'selected' : '' ?>>$55+</option>
            </select>
            </div>
        </div>
        <div>
            <label>Availability (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="Imm/ Start Date" name="availability[]"> <span>Imm/ Start Date</span></div>
            <div><input type="checkbox" value="Part Time" name="availability[]"> <span>Part Time</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Full Time" name="availability[]"> <span>Full Time</span></div>
            <div><input type="checkbox" value="Morning" name="availability[]"> <span>Morning</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Afternoon" name="availability[]"> <span>Afternoon</span></div>
            <div><input type="checkbox" value="Evening" name="availability[]"> <span>Evening</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Weekends/ Shabbos" name="availability[]"> <span>Weekends/ Shabbos</span></div>
            <div><input type="checkbox" value="Night Nurse" name="availability[]"> <span>Night Nurse</span></div>
            </div>
            </div>
        </div>
        <div>
            <label>Tell us about yourself</label>
            <div class="form-field not-required">
            <textarea name="profile_description" class="required"><?php echo isset($desc) ? $desc : '' ?></textarea>
            </div>
        </div>
        <div>
            <label>References</label>
            <div class="form-field not-required">
            <input type="radio" value="1" name="references" class="required" <?php echo isset($ref) && $ref == 1 ? 'checked' : '' ?>/> Yes
            <input type="radio" value="2" name="references" class="required" <?php echo isset($ref) && $ref == 2 ? 'checked' : '' ?> checked/> No
            </div>
        </div>
        <div style="display:none">
            <label>Your references details</label>
            <div class="form-field not-required">
            <textarea style="display:none" name="references_details" class="required"><?php echo isset($ref_det) ? $ref_det : '' ?></textarea>
            </div>
        </div>
        <div>
            <label>Agree to background check?</label>
            <div class="form-field not-required">
            <input type="radio" value="1" name="bg_check" class="required" <?php echo isset($bg_check) && $bg_check == 1 ? 'checked' : '' ?>/> Yes
            <input type="radio" value="2" name="bg_check" class="required" <?php echo isset($bg_check) && $bg_check == 2 ? 'checked' : '' ?> checked/> No
            </div>
        </div>

        <h2>Encouraged but not mandatory fields (check if yes)</h2>

        <div>
            <input type="checkbox" value="1" name="driver_license"> <label>Drivers license</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="vehicle"> <label>Vehicle</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="pick_up_child"> <label>Willing to pick up kids from school</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="cook"> <label>Willing to cook</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="basic_housework"> <label>Willing to do light housework/ cleaning</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="homework_help"> <label>Willing to help with homework</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="sick_child_care"> <label>Willing to care for sick child</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="on_short_notice"> <label>Available on short notice</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="wash"> <label>Willing to wash</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="iron"> <label>Willing to iron</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="fold"> <label>Willing to fold</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="bath_children"> <label>Willing to bathe children</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="bed_children"> <label>Willing to put children to bed</label>
        </div>
        <div>
            <input type="submit" class="btn btn-success" value="Save & Continue"/>
        </div>
    </div>
    </form>
</div>