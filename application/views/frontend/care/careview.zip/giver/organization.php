<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Your Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol> 

<div class="container">
<form action="<?php echo site_url();?>ad/registeruserdetails" method="post">
    <div class="ad-form-container">
        <h1 class="step2">
            Step 2: Organization Details 
        </h1>
    <div>
        <label>Address/ Location</label>
        <div>
        <input type="text" name="location" class="required" value="<?php echo isset($location) ? $location : '' ?>"/>
        </div>    
    </div>
      <div>
        <label>City</label>
        <div>
        <input type="text" name="city" class="required" value="<?php echo isset($city) ? $city : '' ?>"/>
        </div>    
    </div>

     <div>
        <label>Phone</label>
        <div class="form-field">
        <input type="text" name="contact_number" class="required" value="<?php echo isset($phone) ? $phone : '' ?>" id="contact"/>
        </div>
    </div>

    <div>
        <label>Age of owner/ operator</label>
        <div class="form-field">
        <input type="text" name="age" class="required number" value="<?php echo isset($age) ? $age : '' ?>"/>
        </div>
    </div>

    <div>
        <label>Level of religious observance</label>
        <div class="form-field">
        <select name="religious_observance">
            <option value="">Select</option>
            <option value="Yeshivish/ Chasidish">Yeshivish/ Chasidish</option>
            <option value="Orthodox/ Modern Orthodox">Orthodox/ Modern Orthodox</option>
            <option value="Other">Other</option>
            <option value="Not Jewish">Not Jewish</option>
        </select>
        </div>
    </div>

        <?php $this->load->view('frontend/care/photo_upload') ?>

        <?php 
        $acc_cat = $this->uri->segment(3);
        if($acc_cat == 'caregiver'){
            $cat = 1;
        }else{
            $cat = 2;
        }

         $acc_type = $this->uri->segment(4);
        if($acc_type == 'individual'){
            $type = 1;
        }else{
            $type = 2;
        }
    ?>

   

    <div>   
        <!-- <label>Shul membership</label> -->
        <div class="form-field">
        <input type="hidden" name="account_category" value="<?php echo $cat;?>">
        <input type="hidden" name="account_type" value="<?php echo $type;?>">
        </div>
    </div>


        <br/>
        <input type="submit" class="btn btn-success" value="Save & Continue"/>

    </div>
</form>
</div>
<script type="text/javascript" src="<?php echo site_url();?>js/jquery.ui.maskinput.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#contact').mask('999-999-9999');
    });
</script>