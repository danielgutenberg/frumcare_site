<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Your Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>
<div class="container">
        <form action="<?php echo site_url();?>ad/savejobdetails" method="post">
        <div class="ad-form-container">
        <div>
            <h1 class="step3">Step 3: Job Details</h1>
        </div>
        <div>
            <label>Looking to work in (check one or more)</label>
            <div class="form-field">
            <input type="checkbox" value="Patients home" name="looking_to_work[]"> Patients home
            <input type="checkbox" value="Caregiving institude" name="looking_to_work[]"> Caregiving institude
            </div>
        </div>
        <div>
            <label>Years of experience</label>
            <div class="form-field">
            <select name="experience" class="required">
                <option value="">Select years of experience</option>
                <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
            </select>
            </div>
        </div>
        <div>
            <label>Training (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="CPR" name="training[]"> <span>CPR</span></div>
            <div><input type="checkbox" value="First Aid" name="training[]"> <span>First Aid</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Nanny/ Babysitter Course" name="training[]"> <span>Nanny/ Babysitter Course</span></div>
            <div><input type="checkbox" value="Other" name="training[]"> <span>Other</span></div>
            </div>
            </div>
        </div>
        <div>
            <label>Willing to work (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="Autism" name="willing_to_work[]"> <span>Autism</span></div>
            <div><input type="checkbox" value="Down Syndrome" name="willing_to_work[]"> <span>Down Syndrome</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Wheelchair bound" name="willing_to_work[]"> <span>Wheelchair bound</span></div>
            </div>
            </div>
        </div>

        <div>
            <label>Rate</label>
            <div class="form-field">
            <select name="hourly_rate" class="required">
            <option value="">Select rate</option>
            <option value="5-10" <?php echo isset($hr_rate) && $hr_rate == '5-10' ? 'selected' : '' ?>>$5-$10</option>
            <option value="10-15" <?php echo isset($hr_rate) && $hr_rate == '10-15' ? 'selected' : '' ?>>$5-$10</option>
            <option value="15-25" <?php echo isset($hr_rate) && $hr_rate == '15-25' ? 'selected' : '' ?>>$15-$25</option>
            <option value="25-35" <?php echo isset($hr_rate) && $hr_rate == '25-35' ? 'selected' : '' ?>>$25-$35</option>
            <option value="35-45" <?php echo isset($hr_rate) && $hr_rate == '35-45' ? 'selected' : '' ?>>$35-$45</option>
            <option value="45-55" <?php echo isset($hr_rate) && $hr_rate == '45-55' ? 'selected' : '' ?>>$45-$55</option>
            <option value="55+" <?php echo isset($hr_rate) && $hr_rate == '55+' ? 'selected' : '' ?>>$55+</option>
            </select>
            </div>
        </div>
        <div>
            <label>Availability (check one or more)</label>
            <div class="form-field">
                <div class="first-block-checkbox">
            <div><input type="checkbox" value="Imm/ Start Date" name="availability[]"> <span>Imm/ Start Date</span></div>
            <div><input type="checkbox" value="Part Time" name="availability[]"> <span>Part Time</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Full Time" name="availability[]"> <span>Full Time</span></div>
            <div><input type="checkbox" value="Morning" name="availability[]"> <span>Morning</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Afternoon" name="availability[]"> <span>Afternoon</span></div>
            <div><input type="checkbox" value="Evening" name="availability[]"> <span>Evening</span></div>
            </div>
            <div class="first-block-checkbox">
            <div><input type="checkbox" value="Weekends/ Shabbos" name="availability[]"> <span>Weekends/ Shabbos</span></div>
            <div><input type="checkbox" value="24 hr care" name="availability[]"> <span>24 hr care</span></div>
            </div>
            </div>
        </div>
        <div>
            <label>Tell us about yourself</label>
            <div class="form-field">
            <textarea name="profile_description" class="required"><?php echo isset($desc) ? $desc : '' ?></textarea>
            </div>
        </div>
        <div>
            <label>References</label>
            <div class="form-field">
            <input type="radio" value="1" name="references" class="required" <?php echo isset($ref) && $ref == 1 ? 'checked' : '' ?>/> Yes
            <input type="radio" value="2" name="references" class="required" <?php echo isset($ref) && $ref == 2 ? 'checked' : '' ?> checked/> No
            </div>
        </div>
        <div style="display:none">
            <label>Your references details</label>
            <div class="form-field">
            <textarea style="display:none" name="references_details" class="required"><?php echo isset($ref_det) ? $ref_det : '' ?></textarea>
            </div>
        </div>
        <div>
            <label>Agree to background check?</label>
            <div class="form-field">
            <input type="radio" value="1" name="bg_check" class="required" <?php echo isset($bg_check) && $bg_check == 1 ? 'checked' : '' ?>/> Yes
            <input type="radio" value="2" name="bg_check" class="required" <?php echo isset($bg_check) && $bg_check == 2 ? 'checked' : '' ?> checked/> No
            </div>
        </div>

        <h2>Encouraged but not mandatory fields (check if yes)</h2>

        <div>
            <input type="checkbox" value="1" name="driver_license"> <label>Drivers license</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="vehicle"> <label>Vehicle</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="on_short_notice"> <label>Available on short notice</label>
        </div>
        <div>
            <input type="submit" class="btn btn-success" value="Save & Continue"/>
        </div>
        </div>
    </form>
</div>