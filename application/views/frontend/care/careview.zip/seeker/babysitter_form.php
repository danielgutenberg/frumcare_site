<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Job Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>

<div class="container">
<form action="<?php echo site_url();?>ad/add_careseeker_step2" method="post"> 
    <div class="ad-form-container">
        <div>
            <h1 class="step3">Step 2: Job Details</h1>
        </div>
        <div>
            <label>Looking to work in (check one or more)</label>
            <div class="form-field">
            <input type="checkbox" value="My home" name="looking_to_work[]"> My home
            <input type="checkbox" value="Caregivers home" name="looking_to_work[]"> Caregivers home
            </div>
        </div>
        <div>
            <label>Address/ Location</label>
            <div>
            <input type="text" name="location" class="required" value=""/>
            </div>    
        </div>
        <div>
            <label>Phone</label>
            <div class="form-field">
            <input type="text" name="contact_number" class="required" value="" id="contact_number"/>
            </div>
        </div>
        <div>
            <label>Number of children</label>
            <div class="form-field">
            <input type="text" value="" name="number_of_children" class="required number">
            </div>
        </div>
        <div>
            <label>Gender of children</label>
            <div class="form-field">
            <input type="radio" value="1" name="gender" checked> Male
            <input type="radio" value="2" name="gender"> Female
            <input type="radio" value="3" name="gender"> Both
            </div>
        </div>
        <div>
            <label>Ages of children</label>
            <div class="form-field">
            <input type="text" name="age" class="required number" value="<?php echo isset($age) ? $age : '' ?>"/>
            </div>
        </div>
        <div>
            <label>Years of experience</label>
            <div class="form-field">
            <select name="experience" class="required">
                <option value="">Select years of experience</option>
                <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
            </select>
            </div>
        </div>
        <div>
            <label>When you need care</label>
            <div class="form-field">
            <input type="checkbox" value="Occ./ reg./ one time" name="availability[]"> Occ./ reg./ one time
            <input type="checkbox" value="Part Time" name="availability[]"> Part Time
            <input type="checkbox" value="Full Time" name="availability[]"> Full Time
            <input type="checkbox" value="Days/ hours" name="availability[]"> Days/ hours
            <input type="checkbox" value="Asap/ start date" name="availability[]"> Asap/ start date
            <input type="checkbox" value="Evening" name="availability[]"> Evening
            <input type="checkbox" value="Weekends/ Shabbos" name="availability[]"> Weekends/ Shabbos
            <input type="checkbox" value="Night Nurse" name="availability[]"> Night Nurse
            </div>
        </div>
        <div>
            <label>Level of observance necessary</label>
            <div class="form-field">
            <select name="religious_observance">
                <option value="">Select</option>
                <option value="Orthodox">Orthodox</option>
                <option value="Modern Orthodox">Modern orthodox</option>
                <option value="Other">Other</option>
                <option value="Not Jewish">Not necessary</option>
            </select>
            </div>
        </div>
        <div>
            <label>Caregiver age from</label>
            <div class="form-field">
            <select name="age_group" class="required">
                <option value="">Select caregiver age from</option>
                <option value="18-20" <?php echo isset($age_grp) && $age_grp == '18-20' ? 'selected' : '' ?>>18 to 20</option>
                <option value="20-25" <?php echo isset($age_grp) && $age_grp == '20-25' ? 'selected' : '' ?>>20 to 25</option>
                <option value="25-30" <?php echo isset($age_grp) && $age_grp == '25-30' ? 'selected' : '' ?>>25 to 30</option>
                <option value="30+" <?php echo isset($age_grp) && $age_grp == '30+' ? 'selected' : '' ?>>30+</option>
            </select>
            </div>
        </div>
        <div>
            <label>Wage</label>
            <div class="form-field">
                <input type="text" value="" name="hourly_rate" id="wage" class="required">
            <select name="" onchange="change_wage(this.value)">
                <option value="1">per hour</option>
                <option value="2">per month</option>
            </select>
            </div>
        </div>
        <div>
            <label>Tell us about needs</label>
            <div class="form-field">
            <textarea name="profile_description" class="required"><?php echo isset($desc) ? $desc : '' ?></textarea>
            </div>
        </div>
    <h2>Encouraged but not mandatory fields</h2>
    <div>
        <label>Smoker</label>
        <div class="form-field">
        <input type="radio" name="smoker" value="1"> Yes
        <input type="radio" name="smoker" value="2" checked> No
        </div>
    </div>
    <div>
        <label>Languages necessary</label>
        <div class="form-field">
        <select name="language[]" multiple>
            <option value="eng">
                English
            </option>
            <option value="es">
                Spanish
            </option>
            <option value="sign">
                Sign Language
            </option>
        </select>
        </div>
    </div>
    <div>
        <label>Training necessary</label>
        <div class="form-field">
        <input type="checkbox" value="CPR" name="training[]"> CPR
        <input type="checkbox" value="First Aid" name="training[]"> First Aid
        <input type="checkbox" value="Nanny/ Babysitter course" name="training[]"> Nanny/ Babysitter course
        <input type="checkbox" value="Not necessary" name="training[]"> Not necessary
        </div>
    </div>
    <div>
        <label>Minimum experience</label>
        <div class="form-field">
        <select name="experience">
            <option value="">Select minimum experience</option>
            <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
            <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
            <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
            <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
            <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
        </select>
        </div>
        </div>

        <div>
            <input type="checkbox" value="1" name="driver_license"> <label>Drivers license</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="vehicle"> <label>Vehicle</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="pick_up_child"> <label>Must be willing to pick up kids from school</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="cook"> <label>Must be willing to cook/ serve meals</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="basic_housework"> <label>Must be willing to do light housework/ cleaning</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="homework_help"> <label>Must be willing to help with homework</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="sick_child_care"> <label>Must be willing to care for sick child</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="references"> <label>Must have references</label>
        </div>
        <div>
            <input type="checkbox" value="1" name="photo_of_child"> <label>Photo of child/ children</label>
        </div>

        <div>
             <input type="submit" class="btn btn-success" value="Save & Continue"/>
        </div>

    </div>
  </form>
</div>

<script type="text/javascript" src="<?php echo site_url();?>js/jquery.ui.maskinput.js"></script>

<script type="text/javascript">
function change_wage(val){
    if(val==1){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'hourly_rate');
    }
    else if(val=2){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'monthly_rate');    
    }
}
$(document).ready(function(){
    $('#contact_number').mask('999-999-9999');

});
</script>
