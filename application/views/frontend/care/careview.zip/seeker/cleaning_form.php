<?php
/*if(check_user()) {
    $current_user = get_user(check_user());
    $exp = $current_user['experience'];
    $edu = $current_user['education_level'];
    $age_grp = $current_user['age_group'];
    $hr_rate = $current_user['hourly_rate'];
    $desc = $current_user['profile_description'];
    $bg_check = $current_user['agree_bg_check'];
}*/
?>
<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Job Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>


<div class="container">
<form action="<?php echo site_url();?>ad/add_careseeker_step2" method="post">
    <div class="ad-form-container">
        <div>
            <h1 class="step2">Step 2: Job Details</h1>
        </div>
        <div>
            <label>Looking to work for</label>
            <div class="form-field">
            <input type="checkbox" value="Home" name="looking_to_work[]"> Home
            <input type="checkbox" value="Office" name="looking_to_work[]"> Office
            </div>
        </div>
        <div>
            <label>Address/ Location</label>
            <div>
            <input type="text" name="location" class="required" value=""/>
            </div>    
        </div>
        <div>
            <label>Phone</label>
            <div class="form-field">
            <input type="text" name="contact_number" class="required" value=""/>
            </div>
        </div>
        <div>
            <label>Number of rooms</label>
            <div class="form-field">
            <input type="text" name="number_of_rooms" class="required number" value=""/>
            </div>
        </div>

        <div>
            <label>Minimum experience</label>
            <div class="form-field">
            <select name="experience">
                <option value="">Select minimum experience</option>
                <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
            </select>
            </div>
        </div>
        <div>
            <label>Must specialize in</label>
            <div class="form-field">
            <input type="checkbox" value="Floors" name="willing_to_work[]"> Floors
            <input type="checkbox" value="Windows" name="willing_to_work[]"> Windows
            <input type="checkbox" value="Dishes" name="willing_to_work[]"> Dishes
            <input type="checkbox" value="Laundry" name="willing_to_work[]"> Laundry
            <input type="checkbox" value="Wash" name="willing_to_work[]"> Wash
            <input type="checkbox" value="Fold" name="willing_to_work[]"> Fold
            <input type="checkbox" value="Iron" name="willing_to_work[]"> Iron
            <input type="checkbox" value="Furniture" name="willing_to_work[]"> Furniture
            </div>
        </div>

        <div>
            <label>Availability (check one or more)</label>
            <div class="form-field">
            <input type="checkbox" value="Occ./ reg./ one time" name="availability[]"> Occ./ reg./ one time
            <input type="checkbox" value="Part Time" name="availability[]"> Part Time
            <input type="checkbox" value="Full Time" name="availability[]"> Full Time
            <input type="checkbox" value="Days/ hours" name="availability[]"> Days/ hours
            <input type="checkbox" value="Asap/ start date" name="availability[]"> Asap/ start date
            </div>
        </div>
        <div>
            <label>Wage</label>
            <div class="form-field">
                <input type="text" value="" name="hourly_rate" id="wage" class="required">
            <select name="" onchange="change_wage(this.value)">
                <option value="1">per hour</option>
                <option value="2">per month</option>
            </select>
            </div>
        </div>

        <h2>Encouraged but not mandatory fields</h2>
        <div>
            <label>Languages</label>
            <div class="form-field">
            <select name="language[]" multiple>
                <option value="eng">
                    English
                </option>
                <option value="es">
                    Spanish
                </option>
                <option value="sign">
                    Sign Language
                </option>
            </select>
            </div>
        </div>

        <div>
            <label>Gender</label>
            <div class="form-field">
            <input type="radio" value="1" name="gender_of_caregiver" checked> Male
            <input type="radio" value="2" name="gender_of_caregiver"> Female
            </div>
        </div>

        <div>
            <label>Level of observance necessary</label>
            <div class="form-field">
            <select name="religious_observance" class="required">
                <option value="">Select</option>
                <option value="Orthodox">Orthodox</option>
                <option value="Modern Orthodox">Modern orthodox</option>
                <option value="Other">Other</option>
                <option value="Not Jewish">Not necessary</option>
            </select>
            </div>
        </div>
        <div>
            <label>Smoking acceptable</label>
            <div class="form-field">
            <input type="radio" name="smoker" value="1"> Yes
            <input type="radio" name="smoker" value="2" checked> No
            </div>
        </div>
         <div>
            <input type="submit" class="btn btn-success" value="Save & Continue"/>
        </div>
    </div>
    </form>
</div>

<script type="text/javascript">
function change_wage(val){
    if(val==1){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'hourly_rate');
    }
    else if(val=2){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'monthly_rate');    
    }
}
</script>