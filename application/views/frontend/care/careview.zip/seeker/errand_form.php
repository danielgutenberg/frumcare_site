<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Job Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>


<div class="ad-form-container">
<form action="<?php echo site_url();?>ad/add_careseeker_step2" method="post">
<div>
    <h1 class="step2">Step 2: Job Details</h1>
</div>
<div>
    <label>Address/ Location</label>
    <div>
    <input type="text" name="location" class="required" value=""/>
    </div>    
</div>
<div>
    <label>Phone</label>
    <div class="form-field">
    <input type="text" name="contact_number" class="required" value=""/>
    </div>
</div>
<div>
    <label>Description of job</label>
    <div class="form-field">
    <textarea name="job_description" class="required"></textarea>
    </div>
</div>
<div>
    <label>Wage</label>
    <div class="form-field">
        <input type="text" value="" name="hourly_rate" id="wage" class="required">
    <select name="" onchange="change_wage(this.value)">
        <option value="1">per hour</option>
        <option value="2">per month</option>
    </select>
    </div>
</div>

<div>
    <label>Availability (check one or more)</label>
    <div class="form-field">
    <input type="checkbox" value="Occ./ reg./ one time" name="availability[]"> Occ./ reg./ one time
    <input type="checkbox" value="Part Time" name="availability[]"> Part Time
    <input type="checkbox" value="Full Time" name="availability[]"> Full Time
    <input type="checkbox" value="Days/ hours" name="availability[]"> Days/ hours
    <input type="checkbox" value="Asap/ start date" name="availability[]"> Asap/ start date
    </div>
</div>
<div>
    <label>Tell us about needs</label>
    <div class="form-field">
    <textarea name="profile_description" class="required"></textarea>
    </div>
</div>


<h2>Encouraged but not mandatory fields</h2>
<div>
    <label>Languages</label>
    <div class="form-field">
    <select name="language[]" multiple>
        <option value="eng">
            English
        </option>
        <option value="es">
            Spanish
        </option>
        <option value="sign">
            Sign Language
        </option>
    </select>
    </div>
</div>

<div>
    <label>Gender</label>
    <div class="form-field">
    <input type="radio" value="1" name="gender_of_caregiver" checked> Male
    <input type="radio" value="2" name="gender_of_caregiver"> Female
    </div>
</div>

<div>
    <label>Level of observance necessary</label>
    <div class="form-field">
    <select name="religious_observance" class="required">
        <option value="">Select</option>
        <option value="Orthodox">Orthodox</option>
        <option value="Modern Orthodox">Modern orthodox</option>
        <option value="Other">Other</option>
        <option value="Not Jewish">Not necessary</option>
    </select>
    </div>
</div>
<div>
    <label>Smoking acceptable</label>
    <div class="form-field">
    <input type="radio" name="smoker" value="1"> Yes
    <input type="radio" name="smoker" value="2" checked> No
    </div>
</div>
<div>
    <label>Minimum experience</label>
    <div class="form-field">
    <select name="experience">
        <option value="">Select minimum experience</option>
        <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
        <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
        <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
        <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
        <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
    </select>
    </div>
</div>
<div>
    <input type="checkbox" value="1" name="driver_license"> <label>Drivers license</label>
</div>
<div>
    <input type="checkbox" value="1" name="vehicle"> <label>Vehicle</label>
</div>

<div>
   <input type="submit" class="btn btn-success" value="Save & Continue"/>
</div>

    </form>
</div>

<script type="text/javascript">
function change_wage(val){
    if(val==1){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'hourly_rate');
    }
    else if(val=2){
        $('#wage').removeAttr('name');
        $('#wage').attr('name', 'monthly_rate');    
    }
}
</script>