<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Job Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>


<div class="ad-form-container">
<form action="<?php echo site_url();?>/ad/add_careseeker_step2">
<div>
    <h1 class="step2">Step 2: Job Details</h1>
</div>
<div>
    <label>Address/ Location</label>
    <div>
    <input type="text" name="location" class="required" value=""/>
    </div>    
</div>
<div>
    <label>Phone</label>
    <div class="form-field">
    <input type="text" name="contact_number" class="required" value=""/>
    </div>
</div>
<div>
    <label>Age of patient</label>
    <div class="form-field">
    <input type="text" name="age" class="required number" value=""/>
    </div>
</div>

<div>
    <label>Gender of patient</label>
    <div class="form-field">
    <input type="radio" value="1" name="gender" checked> Male
    <input type="radio" value="2" name="gender"> Female
    </div>
</div>
<div>
    <label>Condition(s) of patient</label>
    <div class="form-field">
    <input type="checkbox" value="Condition1" name="conditions_of_paitent[]"> Condition1
    <input type="checkbox" value="Condition2" name="conditions_of_paitent[]"> Condition2
    </div>
</div>

<div>
    <label>Type of therapist wanted</label>
    <div class="form-field">
    <input type="text" value="" name="type_of_therapy" class="required">
    </div>
</div>
<div>
    <label>Tell us about yourself</label>
    <div class="form-field">
    <textarea name="profile_description" class="required"></textarea>
    </div>
</div>

<h2>Encouraged but not mandatory fields</h2>

<div>
    <label>Languages</label>
    <div class="form-field">
    <select name="language[]" multiple>
        <option value="eng">
            English
        </option>
        <option value="es">
            Spanish
        </option>
        <option value="sign">
            Sign Language
        </option>
    </select>
    </div>
</div>

<div>
    <label>Gender of therapist</label>
    <div class="form-field">
    <input type="radio" value="1" name="gender_of_caregiver" checked> Male
    <input type="radio" value="2" name="gender_of_caregiver"> Female
    </div>
</div>

<div>
    <label>Level of observance necessary</label>
    <div class="form-field">
    <select name="religious_observance" class="required">
        <option value="">Select</option>
        <option value="Orthodox">Orthodox</option>
        <option value="Modern Orthodox">Modern orthodox</option>
        <option value="Other">Other</option>
        <option value="Not Jewish">Not necessary</option>
    </select>
    </div>
</div>
<div>
    <label>Must accept insurance</label>
    <div class="form-field">
    <input type="radio" value="1" name="accept_insurance"/> Yes
    <input type="radio" value="2" name="accept_insurance" checked/> No
    </div>
</div>
<div>
    <input type="submit" class="btn btn-success" value="Save & Continue"/>
</div>
</div>
