<ol class="progtrckr" data-progtrckr-steps="3">
    <li class="progtrckr-done">Sign up</li>
    <li class="progtrckr-done">Job Details</li>
    <li class="progtrckr-done">Start Getting Calls</li>
</ol>

<form action="<?php echo site_url();?>ad/add_careseeker_step2" method="post">
    <div class="ad-form-container">
        <div>
            <h1 class="step2">Step 2: Job Details</h1>
        </div>
        <div>
            <label>Address/ Location</label>
            <div>
            <input type="text" name="location" class="required" value=""/>
            </div>    
        </div>
        <div>
            <label>Phone</label>
            <div class="form-field">
            <input type="text" name="contact_number" class="required" value=""/>
            </div>
        </div>
        <div>
            <label>Ages of student</label>
            <div class="form-field">
            <input type="text" name="age" class="required number" value="<?php echo isset($age) ? $age : '' ?>"/>
            </div>
        </div>

        <div>
            <label>Gender of student</label>
            <div class="form-field">
            <input type="radio" value="1" name="gender" checked> Male
            <input type="radio" value="2" name="gender"> Female
            </div>
        </div>

        <div>
            <label>Looking for help in the following subject(s):</label>
            <div class="form-field">
            <input type="checkbox" value="Elementary school" name="subjects[]"> Elementary school
            <input type="checkbox" value="High school" name="subjects[]"> High school
            <input type="checkbox" value="Post high school" name="subjects[]"> Post high school
            <input type="checkbox" value="Special ed" name="subjects[]"> Special ed
            <input type="checkbox" value="Music" name="subjects[]"> Music
            <input type="checkbox" value="Art" name="subjects[]"> Art
            <input type="checkbox" value="Ohter" name="subjects[]"> Ohter
            </div>
        </div>


        <h2>Encouraged but not mandatory fields</h2>

        <div>
            <label>Language</label>
            <div class="form-field">
            <select name="language[]" multiple>
                <option value="eng">
                    English
                </option>
                <option value="es">
                    Spanish
                </option>
                <option value="sign">
                    Sign Language
                </option>
            </select>
            </div>
        </div>

        <div>
            <label>Gender of tutor</label>
            <div class="form-field">
            <input type="radio" value="1" name="gender_of_caregiver" checked> Male
            <input type="radio" value="2" name="gender_of_caregiver"> Female
            </div>
        </div>
        <div>
            <label>Tutor age from</label>
            <div class="form-field">
            <select name="age_group" class="required">
                <option value="">Select tutor age from</option>
                <option value="10-20" <?php echo isset($age_grp) && $age_grp == '1-5' ? 'selected' : '' ?>>10 to 20</option>
                <option value="20-30" <?php echo isset($age_grp) && $age_grp == '5-10' ? 'selected' : '' ?>>20 to 30</option>
                <option value="30-40" <?php echo isset($age_grp) && $age_grp == '10-15' ? 'selected' : '' ?>>30 to 40</option>
            </select>
            </div>
        </div>
        <div>
            <label>Smoking acceptable</label>
            <div class="form-field">
            <input type="radio" name="smoker" value="1"> Yes
            <input type="radio" name="smoker" value="2" checked> No
            </div>
        </div>
        <div>
            <label>Level of observance necessary</label>
            <div class="form-field">
            <select name="religious_observance">
                <option value="">Select</option>
                <option value="Orthodox">Orthodox</option>
                <option value="Modern Orthodox">Modern orthodox</option>
                <option value="Other">Other</option>
                <option value="Not Jewish">Not necessary</option>
            </select>
            </div>
        </div>
        <div>
            <label>Minimum years experience</label>
            <div class="form-field">
            <select name="experience" class="required">
                <option value="">Select Minimum years experience</option>
                <option value="1" <?php echo isset($exp) && $exp == 1 ? 'selected' : '' ?>>1 year</option>
                <option value="2" <?php echo isset($exp) && $exp == 2 ? 'selected' : '' ?>>2 years</option>
                <option value="3" <?php echo isset($exp) && $exp == 3 ? 'selected' : '' ?>>3 years</option>
                <option value="4" <?php echo isset($exp) && $exp == 4 ? 'selected' : '' ?>>4 years</option>
                <option value="5+" <?php echo isset($exp) && $exp == '5+' ? 'selected' : '' ?>>5+ years</option>
            </select>
            </div>
        </div>

        <div>
            <label>Training/ certification required</label>
            <div class="form-field">
            <input type="checkbox" value="CPR" name="training[]"> CPR
            <input type="checkbox" value="First Aid" name="training[]"> First Aid
            <input type="checkbox" value="Nanny/ Babysitter course" name="training[]"> Nanny/ Babysitter course
            <input type="checkbox" value="Not necessary" name="training[]"> Not necessary
            </div>
        </div>
        <div>
            <?php /* <input type="checkbox" value="1" name="photo_of_child"> <label>Photo</label> */?>
        </div>
        <div>
            <input type="submit" class="btn btn-success" value="Save & Continue"/>
        </div>
    </div>
</form>
