$(document).ready(function() {
        $('#example').dataTable();
});

// $(function(){
// 	$('#example').dataTable();
// });	